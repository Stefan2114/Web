package com.battleships.battleships_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.battleships.battleships_backend.servlet.GameServlet;
import com.battleships.battleships_backend.servlet.LoginServlet;
import com.battleships.battleships_backend.servlet.LogoutServlet;

@SpringBootApplication
@ServletComponentScan

public class BattleshipsBackendApplication implements WebMvcConfigurer {

	public static void main(String[] args) {
		SpringApplication.run(BattleshipsBackendApplication.class, args);
	}

}
